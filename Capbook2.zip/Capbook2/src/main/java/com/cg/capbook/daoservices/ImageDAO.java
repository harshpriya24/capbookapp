package com.cg.capbook.daoservices;

public interface ImageDAO {

}
