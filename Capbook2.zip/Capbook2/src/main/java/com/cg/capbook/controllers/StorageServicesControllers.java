package com.cg.capbook.controllers;

import org.springframework.stereotype.Controller;

@Controller
public class StorageServicesControllers {
 
}
