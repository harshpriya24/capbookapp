package com.cg.capbook.aspect;

public class CapbookAspect {

}
