package com.cg.capbook;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Capbook2Application {

	public static void main(String[] args) {
		SpringApplication.run(Capbook2Application.class, args);
	}

}
