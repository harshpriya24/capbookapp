package com.cg.capbook.beans;

public class ChangePassword {

 	private String oldpassword;
	private String newpassword;
}
